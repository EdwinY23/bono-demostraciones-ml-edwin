from pathlib import Path
from html import escape
import re,shutil,json
import mistune
from jinja2 import Template
root=Path('/mnt/data/Bono_Demostraciones_ML_Edwin_Yunis')
docs=root/'docs'
(docs/'figuras').mkdir(parents=True,exist_ok=True)
for f in (root/'figuras').glob('*.png'): shutil.copyfile(f,docs/'figuras'/f.name)
chapters=[('intro','Inicio','Introducción y mapa del bono'),('01','Riesgo en K-NN','Riesgo verdadero y empírico'),('02','Cota de 1-NN','Dos casos de η(x)'),('03','Ridge: propiedades','Esperanza, covarianza, sesgo y ECM'),('04','Ridge: derivadas','Centrado e intercepto'),('05','Estandarización','Igualdades (3.11)'),('06','Lasso','Subgradiente, umbral suave y LARS'),('07','Árbol corregido','Gini y Age < 49'),('08','AdaBoost','Pesos, actualización y cota')]
md=mistune.create_markdown(escape=False,plugins=['table','math','strikethrough'])
T='''<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="Demostraciones de Machine Learning, trabajo individual de Edwin Yunis"><title>{{ title }} · Edwin Yunis</title><link rel="stylesheet" href="styles.css"><script>window.MathJax={tex:{inlineMath:[["\\(","\\)"],["$","$"]],displayMath:[["\\[","\\]"],["$$","$$"]]},options:{skipHtmlTags:['script','noscript','style','textarea','pre','code']}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script></head><body>
<div class="layout"><aside class="sidebar"><div class="brand"><span class="mark">∑</span><div><b>Machine Learning</b><small>Bono académico · Demostraciones</small></div></div><p class="sidecap">AUTOR</p><p class="student">Edwin Yunis</p><p class="sidecap">CAPÍTULOS</p><nav aria-label="Capítulos">{% for c in chapters %}<a href="{{c[0]}}.html" class="nav {% if c[0]==id %}selected{% endif %}"><span class="navnum">{{'%02d'|format(loop.index0)}}</span><span><b>{{c[1]}}</b><small>{{c[2]}}</small></span></a>{% endfor %}</nav><div class="sidefoot">Dr. Lihki Rubio<br>Maestría en Ingeniería Industrial<br>Universidad del Norte · 2026</div></aside>
<div class="mainwrap"><header class="topbar"><div><b>Demostraciones matemáticas</b><span> · Solución individual</span></div><div class="topright">Edwin Yunis</div></header><main class="main"><div class="crumb">BONO ACADÉMICO <span>/</span> {{title |e}}</div><article class="paper">{{body|safe}}</article><div class="nextprev">{% if prev %}<a href="{{prev[0]}}.html">← {{prev[1]}}</a>{% endif %}<span></span>{% if next %}<a href="{{next[0]}}.html">{{next[1]}} →</a>{% endif %}</div><footer>Documento académico individual · Edwin Yunis · Fuentes: notas del profesor y consignas de la tarea.</footer></main></div></div></body></html>'''
template=Template(T)
def render_markdown(txt):
    blocks=[]
    def hold(m):
        i=len(blocks)
        blocks.append(m.group(1).strip())
        return f'\n\nMATHBLOCKTOKEN{i}END\n\n'
    txt=re.sub(r'\$\$(.*?)\$\$',hold,txt,flags=re.S)
    html=md(txt)
    for i,v in enumerate(blocks):
        html=html.replace(f'<p>MATHBLOCKTOKEN{i}END</p>',f'<div class="math-block">\\[{escape(v)}\\]</div>')
    return html
for i,(ident,short,sub) in enumerate(chapters):
    txt=(root/f'{ident}.md').read_text(encoding='utf-8')
    page=template.render(id=ident,title=short,body=render_markdown(txt),chapters=chapters,prev=chapters[i-1] if i else None,next=chapters[i+1] if i+1<len(chapters) else None)
    (docs/f'{ident}.html').write_text(page,encoding='utf-8')
(docs/'index.html').write_text((docs/'intro.html').read_text(encoding='utf-8'),encoding='utf-8')
(docs/'.nojekyll').write_text('',encoding='utf-8')
print('HTML pages:',len(list(docs.glob('*.html'))),'figure count:',len(list((docs/'figuras').glob('*.png'))))
